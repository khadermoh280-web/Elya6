package com.elya.app
import android.annotation.SuppressLint
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

const val HOME = "https://appassets.androidplatform.net/assets/index.html"

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    inner class Bridge {
        @JavascriptInterface
        fun vpn(): Boolean {
            val cm = getSystemService(ConnectivityManager::class.java)
            val c = cm.getNetworkCapabilities(cm.activeNetwork)
            return c?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("intent:")) {
                    try { startActivity(Intent.parseUri(u, Intent.URI_INTENT_SCHEME)) } catch (e: Exception) {}
                    return true
                }
                return false
            }
        }
        val home = Button(this).apply {
            text = "⌂ Elya"; setTextColor(0xFFE6F1FF.toInt()); setBackgroundColor(0xCC0C1726.toInt())
            setOnClickListener { web.loadUrl(HOME) }
        }
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(home, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply { setMargins(24, 0, 0, 90) })
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else finish() }
        })
        val auth = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(auth) == BiometricManager.BIOMETRIC_SUCCESS) {
            val info = BiometricPrompt.PromptInfo.Builder().setTitle("Elya").setSubtitle("تأكيد الهوية").setAllowedAuthenticators(auth).build()
            BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { setContentView(root); web.loadUrl(HOME) }
                override fun onAuthenticationError(c: Int, m: CharSequence) { finish() }
            }).authenticate(info)
        } else { setContentView(root); web.loadUrl(HOME) }
    }
}
